Download and place your Aiven certificates in this directory.
Do not change their names.